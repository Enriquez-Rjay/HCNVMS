<?php
// scripts/check_login.php
// Usage: php scripts/check_login.php username password
// This uses the same logic as auth/login.php to help debug credential issues.
if ($argc < 3) {
    echo "Usage: php scripts/check_login.php <username_or_email> <password>\n";
    exit(1);
}
$username = $argv[1];
$password = $argv[2];

$mysqli = require __DIR__ . '/../config/db.php';

$stmt = $mysqli->prepare('SELECT id, username, password_hash, role FROM users WHERE username = ? OR email = ? LIMIT 1');
if (!$stmt) {
    echo "Prepare failed: " . $mysqli->error . "\n";
    exit(1);
}

$stmt->bind_param('ss', $username, $username);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();

if (!$user) {
    echo "No user found for: {$username}\n";
    exit(2);
}

echo "Found user: id={$user['id']} username={$user['username']} role={$user['role']}\n";
echo "Stored hash: " . substr($user['password_hash'],0,60) . "...\n";

if (password_verify($password, $user['password_hash'])) {
    echo "Password OK\n";
    exit(0);
} else {
    echo "Password mismatch\n";
    exit(3);
}

?>
