-- sql/seed_admin_data.sql
-- Sample seed data to populate tables for admin dashboard metrics
USE `healthcenter`;

-- Create vaccination_records table if it doesn't exist (stores who got which vaccine)
CREATE TABLE IF NOT EXISTS `vaccination_records` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `patient_id` INT UNSIGNED NOT NULL,
  `vaccine_id` INT UNSIGNED NOT NULL,
  `date_given` DATE NOT NULL,
  `dose` INT NOT NULL DEFAULT 1,
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `vr_patient_idx` (`patient_id`),
  KEY `vr_vaccine_idx` (`vaccine_id`),
  CONSTRAINT `vr_patient_fk` FOREIGN KEY (`patient_id`) REFERENCES `users`(`id`) ON DELETE CASCADE,
  CONSTRAINT `vr_vaccine_fk` FOREIGN KEY (`vaccine_id`) REFERENCES `vaccines`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Insert sample vaccines
INSERT INTO `vaccines` (`name`, `manufacturer`, `description`, `storage_condition`, `created_at`) VALUES
('BCG', 'Manufacturer A', 'Bacillus Calmette-Guérin vaccine', '2-8°C, Protect from light', NOW()),
('Polio', 'Manufacturer B', 'Polio vaccine', '2-8°C', NOW()),
('DPT', 'Manufacturer C', 'DPT vaccine', '2-8°C', NOW()),
('HepB', 'Manufacturer D', 'Hepatitis B vaccine', '2-8°C', NOW()),
('MMR', 'Manufacturer E', 'Measles, Mumps, Rubella vaccine', '2-8°C', NOW()),
('Hib', 'Manufacturer F', 'Haemophilus influenzae type b vaccine', '2-8°C', NOW())
ON DUPLICATE KEY UPDATE name = VALUES(name);

-- Insert sample vaccine batches (quantities)
INSERT INTO `vaccine_batches` (`vaccine_id`, `batch_number`, `quantity_received`, `quantity_available`, `expiry_date`, `received_at`, `storage_location`, `created_at`)
VALUES
((SELECT id FROM vaccines WHERE name='BCG' LIMIT 1), 'BCG-2024-01', 100, 12, '2024-07-15', '2024-01-15', 'Cold Room A', NOW()),
((SELECT id FROM vaccines WHERE name='Polio' LIMIT 1), 'POLIO-2025-02', 500, 300, '2026-02-01', '2025-02-01', 'Cold Room B', NOW()),
((SELECT id FROM vaccines WHERE name='DPT' LIMIT 1), 'DPT-2025-03', 400, 340, '2026-05-01', '2025-03-10', 'Cold Room B', NOW()),
((SELECT id FROM vaccines WHERE name='HepB' LIMIT 1), 'HEPB-2024-05', 200, 50, '2025-11-30', '2024-05-20', 'Cold Room C', NOW()),
((SELECT id FROM vaccines WHERE name='MMR' LIMIT 1), 'MMR-2023-09', 80, 45, '2024-07-01', '2023-09-10', 'Cold Room A', NOW()),
((SELECT id FROM vaccines WHERE name='Hib' LIMIT 1), 'HIB-2025-06', 150, 90, '2026-06-30', '2025-06-01', 'Cold Room C', NOW())
ON DUPLICATE KEY UPDATE batch_number = VALUES(batch_number);

-- Seed a few extra patient users (password hashes reused from existing patient entry for convenience)
INSERT INTO `users` (`username`, `password_hash`, `role`, `full_name`, `email`, `created_at`, `status`) VALUES
('patient2', '$2y$10$U/xX8Y.AJKbuRDmIAE07W.rTewtnJawj5awo9Bb/X8khIcAwNpwrW', 'patient', 'Maria Santos', 'maria.santos@example.com', NOW(), 'active'),
('patient3', '$2y$10$U/xX8Y.AJKbuRDmIAE07W.rTewtnJawj5awo9Bb/X8khIcAwNpwrW', 'patient', 'Jose Reyes', 'jose.reyes@example.com', NOW(), 'active'),
('patient4', '$2y$10$U/xX8Y.AJKbuRDmIAE07W.rTewtnJawj5awo9Bb/X8khIcAwNpwrW', 'patient', 'Ana Lopez', 'ana.lopez@example.com', NOW(), 'active')
;

-- Insert patient profiles for the patients (if patient_profiles exists)
INSERT INTO `patient_profiles` (`user_id`, `child_name`, `birth_date`, `guardian_name`, `address`, `created_at`)
VALUES
((SELECT id FROM users WHERE username='Patient' LIMIT 1), 'Child One', '2022-05-12', 'John Dave Timkang', 'Some address', NOW()),
((SELECT id FROM users WHERE username='patient2' LIMIT 1), 'Child Two', '2023-04-01', 'Maria Santos', 'Address 2', NOW()),
((SELECT id FROM users WHERE username='patient3' LIMIT 1), 'Child Three', '2021-11-10', 'Jose Reyes', 'Address 3', NOW()),
((SELECT id FROM users WHERE username='patient4' LIMIT 1), 'Child Four', '2020-08-22', 'Ana Lopez', 'Address 4', NOW())
ON DUPLICATE KEY UPDATE user_id = VALUES(user_id);

-- Insert vaccination records (some patients have records, others don't)
INSERT INTO `vaccination_records` (`patient_id`, `vaccine_id`, `date_given`, `dose`, `created_at`)
VALUES
((SELECT id FROM users WHERE username='Patient' LIMIT 1), (SELECT id FROM vaccines WHERE name='BCG' LIMIT 1), '2022-05-20', 1, NOW()),
((SELECT id FROM users WHERE username='patient2' LIMIT 1), (SELECT id FROM vaccines WHERE name='Polio' LIMIT 1), '2023-04-10', 1, NOW()),
((SELECT id FROM users WHERE username='patient2' LIMIT 1), (SELECT id FROM vaccines WHERE name='DPT' LIMIT 1), '2023-04-10', 1, NOW()),
((SELECT id FROM users WHERE username='patient3' LIMIT 1), (SELECT id FROM vaccines WHERE name='HepB' LIMIT 1), '2021-12-01', 1, NOW())
;

-- Insert sample vaccine transactions (receive) to match batch data
INSERT INTO `vaccine_transactions` (`batch_id`, `type`, `quantity`, `notes`, `performed_by`, `created_at`)
VALUES
((SELECT id FROM vaccine_batches WHERE batch_number='BCG-2024-01' LIMIT 1), 'receive', 100, 'Initial stock', 1, NOW()),
((SELECT id FROM vaccine_batches WHERE batch_number='POLIO-2025-02' LIMIT 1), 'receive', 500, 'Initial stock', 1, NOW())
ON DUPLICATE KEY UPDATE quantity = VALUES(quantity);

-- Insert appointments including some scheduled today
INSERT INTO `appointments` (`patient_id`, `health_worker_id`, `scheduled_at`, `status`, `notes`, `created_at`)
VALUES
((SELECT id FROM users WHERE username='patient2' LIMIT 1), (SELECT id FROM users WHERE role='health_worker' LIMIT 1), CONCAT(CURDATE(),' 09:00:00'), 'scheduled', 'Routine vaccination', NOW()),
((SELECT id FROM users WHERE username='patient3' LIMIT 1), (SELECT id FROM users WHERE role='health_worker' LIMIT 1), CONCAT(CURDATE(),' 10:30:00'), 'scheduled', 'Follow-up', NOW()),
((SELECT id FROM users WHERE username='patient4' LIMIT 1), NULL, CONCAT(DATE_ADD(CURDATE(), INTERVAL 1 DAY),' 14:00:00'), 'scheduled', 'Next day appt', NOW())
;

-- Update quantity_available on batches based on transactions (simple safe update)
UPDATE vaccine_batches vb
LEFT JOIN (
  SELECT batch_id, SUM(CASE WHEN type='receive' THEN quantity WHEN type='use' THEN -quantity ELSE 0 END) AS delta
  FROM vaccine_transactions
  GROUP BY batch_id
) t ON t.batch_id = vb.id
SET vb.quantity_available = GREATEST(0, vb.quantity_received + COALESCE(t.delta,0));

-- Done seeding
SELECT 'SEEDING_COMPLETE' AS status;
