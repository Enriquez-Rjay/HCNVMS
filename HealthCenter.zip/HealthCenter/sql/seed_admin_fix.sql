-- sql/seed_admin_fix.sql
-- Safely insert sample users without causing duplicate-key errors
USE `healthcenter`;

-- Insert patients but skip if username already exists (no-op on duplicate)
INSERT INTO `users` (`username`, `password_hash`, `role`, `full_name`, `email`, `created_at`, `status`)
VALUES
('patient2', '$2y$10$U/xX8Y.AJKbuRDmIAE07W.rTewtnJawj5awo9Bb/X8khIcAwNpwrW', 'patient', 'Maria Santos', 'maria.santos@example.com', NOW(), 'active'),
('patient3', '$2y$10$U/xX8Y.AJKbuRDmIAE07W.rTewtnJawj5awo9Bb/X8khIcAwNpwrW', 'patient', 'Jose Reyes', 'jose.reyes@example.com', NOW(), 'active'),
('patient4', '$2y$10$U/xX8Y.AJKbuRDmIAE07W.rTewtnJawj5awo9Bb/X8khIcAwNpwrW', 'patient', 'Ana Lopez', 'ana.lopez@example.com', NOW(), 'active')
ON DUPLICATE KEY UPDATE username = VALUES(username);

-- Ensure patient_profiles exist for these users (insert if missing)
INSERT INTO `patient_profiles` (`user_id`, `child_name`, `birth_date`, `guardian_name`, `address`, `created_at`)
SELECT u.id, p.child_name, p.birth_date, p.guardian_name, p.address, NOW()
FROM (
  SELECT 'patient2' AS username, 'Child Two' AS child_name, '2023-04-01' AS birth_date, 'Maria Santos' AS guardian_name, 'Address 2' AS address
  UNION ALL
  SELECT 'patient3','Child Three','2021-11-10','Jose Reyes','Address 3'
  UNION ALL
  SELECT 'patient4','Child Four','2020-08-22','Ana Lopez','Address 4'
) AS p
JOIN users u ON u.username = p.username
LEFT JOIN patient_profiles pp ON pp.user_id = u.id
WHERE pp.user_id IS NULL;

-- Done
SELECT 'FIXED_USERS' AS status;
