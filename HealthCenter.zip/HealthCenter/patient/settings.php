<?php
require_once __DIR__ . '/../config/session.php';
$mysqli = require __DIR__ . '/../config/db.php';
?>
<!-- Converted from settings.html -->
<?php include __DIR__ . '/../patient/settings.html'; ?>
