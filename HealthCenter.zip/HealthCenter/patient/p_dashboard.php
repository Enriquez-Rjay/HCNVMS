<?php
require_once __DIR__ . '/../config/session.php';
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'patient') {
  header('Location: /HealthCenter/login.html?error=' . rawurlencode('Please sign in as patient'));
  exit;
}
$displayName = $_SESSION['username'] ?? 'Patient';
?>
<!DOCTYPE html>

<html class="light" lang="en"><head>
<meta charset="utf-8"/>
<meta content="width=device-width, initial-scale=1.0" name="viewport"/>
<title>Vaccination Records - HCNVMS</title>
<script src="https://cdn.tailwindcss.com?plugins=forms,container-queries"></script>
<link href="https://fonts.googleapis.com/css2?family=Public+Sans:ital,wght@0,100..900;1,100..900&amp;display=swap" rel="stylesheet"/>
<link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:wght,FILL@100..700,0..1&amp;display=swap" rel="stylesheet"/>
<style>
        .material-symbols-outlined {
            font-variation-settings:
            'FILL' 0,
            'wght' 400,
            'GRAD' 0,
            'opsz' 24
        }
    </style>
<script id="tailwind-config">
      tailwind.config = {
        darkMode: "class",
        theme: {
          extend: {
            colors: {
              "primary": "#2b8cee",
              "background-light": "#f6f7f8",
              "background-dark": "#101922",
            },
          },
        },
      }
    </script>
</head>
<body class="font-display bg-background-light dark:bg-background-dark text-[#111418] dark:text-gray-200">
<div class="relative flex h-auto min-h-screen w-full flex-col">
<div class="flex h-full grow">
<!-- Side Navigation Bar -->
<aside class="flex h-full min-h-screen w-64 flex-col justify-between border-r border-gray-200 bg-white p-4 dark:border-gray-800 dark:bg-background-dark">
<div class="flex flex-col gap-6">
<div class="flex items-center gap-3 px-3">
<div class="size-8 text-primary">
<!-- logo -->
</div>
<h1 class="text-[#111418] dark:text-gray-200 text-lg font-bold">HCNVMS</h1>
</div>
<div class="flex flex-col gap-2">
<a class="flex items-center gap-3 rounded-lg px-3 py-2 text-[#617589] dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-gray-800" href="#">
<span class="material-symbols-outlined">dashboard</span>
<p class="text-sm font-medium">Dashboard</p>
</a>
<!-- other links -->
</div>
</div>
<div class="flex flex-col gap-1">
<a class="flex items-center gap-3 rounded-lg px-3 py-2 text-[#617589] dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-gray-800" href="/HealthCenter/auth/logout.php">
<span class="material-symbols-outlined">logout</span>
<p class="text-sm font-medium">Log out</p>
</a>
</div>
</aside>
<main class="flex-1">
<!-- Top Navigation Bar -->
<header class="flex items-center justify-end whitespace-nowrap border-b border-solid border-gray-200 bg-white px-8 py-3 dark:border-gray-800 dark:bg-background-dark">
<div class="flex items-center gap-4">
<button class="flex h-10 w-10 cursor-pointer items-center justify-center overflow-hidden rounded-lg bg-gray-100 text-[#111418] dark:bg-gray-800 dark:text-gray-300">
<span class="material-symbols-outlined">notifications</span>
</button>
<div class="bg-center bg-no-repeat aspect-square bg-cover rounded-full size-10" data-alt="User profile picture" style='background-image: url("https://lh3.googleusercontent.com/aida-public/AB6AXuDy5Y3Gp8CjcHZbiXoYUvHpsAGgBnTWnqQoJ8MGYxKTooBXJUMb3LsQdJNXrfsjN0WdsXCFVJi3gm_sKGYjoqlLrmwsIlOa8fQavlDkfs3s2VbXV0iLoRZ8omUxG5Pfn0giZARnbnvVGGSlT7tt_i85Ex_vLyyTVPfKLzEpaKNTSC8d1JrWqTjh6mpd60l1MLMuLfGqpLYmhQCYXOh-GUDlFjL30jfdw9xAv7Z2clgMQN8Q_5bTiTqn8F9tRx9u_158GLunQR7d-OU");'></div>
</div>
</header>
<div class="p-8">
<div class="mx-auto max-w-5xl">
<!-- Page Heading -->
<div class="flex flex-wrap items-start justify-between gap-4">
<p class="text-[#111418] dark:text-white text-4xl font-black leading-tight tracking-[-0.033em] min-w-72">Vaccination Record</p>
<div class="flex items-center gap-2">
  <div class="flex gap-2">
    <button class="flex max-w-[480px] cursor-pointer items-center justify-center overflow-hidden rounded-lg h-10 border border-gray-300 dark:border-gray-700 bg-white dark:bg-gray-800 text-[#111418] dark:text-gray-200 gap-2 text-sm font-medium leading-normal px-4">
      <span class="material-symbols-outlined text-base">print</span>
      <span>Print Record</span>
    </button>
  </div>
  <a href="/HealthCenter/auth/logout.php" class="ml-4 inline-flex items-center gap-2 rounded-md bg-red-500 px-3 py-2 text-white hover:bg-red-600">Logout</a>
</div>
</div>
<!-- rest of page content remains the same -->
</div>
</div>
</main>
</div>
</div>
</body></html>
