<?php
require_once __DIR__ . '/../config/session.php';
$mysqli = require __DIR__ . '/../config/db.php';
?>
<!DOCTYPE html>
<html class="light" lang="en"><head>
<meta charset="utf-8"/>
<meta content="width=device-width, initial-scale=1.0" name="viewport"/>
<title>HCNVMS - User Management</title>
<script src="https://cdn.tailwindcss.com?plugins=forms,container-queries"></script>
<link href="https://fonts.googleapis.com/css2?family=Public+Sans:wght@400;500;600;700;800;900&amp;display=swap" rel="stylesheet"/>
<link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" rel="stylesheet"/>
<style>
		.material-symbols-outlined {
			font-variation-settings: 'FILL' 0, 'wght' 400, 'GRAD' 0, 'opsz' 24;
		}
	</style>
<script>
		tailwind.config = {
			darkMode: "class",
			theme: {
				extend: {
					colors: {
						"primary": "#4A90E2",
						"background-light": "#F4F7FA",
						"background-dark": "#101922",
						"surface": "#FFFFFF",
						"surface-dark": "#1A242E",
						"text-light": "#333333",
						"text-dark": "#E0E0E0",
						"text-secondary-light": "#617589",
						"text-secondary-dark": "#A0AEC0",
						"border-light": "#E2E8F0",
						"border-dark": "#2D3748",
						"success": "#2ECC71",
						"warning": "#F39C12",
						"danger": "#E74C3C",
					},
					fontFamily: {
						"display": ["Public Sans", "sans-serif"]
					},
					borderRadius: {
						"DEFAULT": "0.5rem",
						"lg": "0.75rem",
						"xl": "1rem",
						"full": "9999px"
					},
				},
			},
		}
	</script>
</head>
<body class="font-display bg-background-light dark:bg-background-dark text-text-light dark:text-text-dark">
<div class="relative flex min-h-screen w-full flex-row">
<aside class="flex h-screen w-64 flex-col justify-between bg-surface dark:bg-surface-dark p-4 border-r border-border-light dark:border-border-dark sticky top-0">
<div class="flex flex-col gap-8">
<div class="flex items-center gap-3 px-3 text-primary">
<span class="material-symbols-outlined text-3xl">vaccines</span>
<h2 class="text-text-light dark:text-text-dark text-xl font-bold leading-tight tracking-[-0.015em]">HCNVMS</h2>
</div>
<div class="flex flex-col gap-2">
<a class="flex items-center gap-3 px-3 py-2.5 rounded-lg hover:bg-primary/10 dark:hover:bg-primary/20" href="/HealthCenter/admin/admin_dashboard.php">
<span class="material-symbols-outlined">dashboard</span>
<p class="text-sm font-medium leading-normal">Dashboard</p>
</a>
<a class="flex items-center gap-3 px-3 py-2.5 rounded-lg bg-primary/20 text-primary" href="/HealthCenter/admin/user_management.php">
<span class="material-symbols-outlined" style="font-variation-settings: 'FILL' 1;">group</span>
<p class="text-sm font-semibold leading-normal">User Management</p>
</a>
<a class="flex items-center gap-3 px-3 py-2.5 rounded-lg hover:bg-primary/10 dark:hover:bg-primary/20" href="/HealthCenter/admin/health_worker_management.php">
<span class="material-symbols-outlined">health_and_safety</span>
<p class="text-sm font-medium leading-normal">Health Worker Mgt.</p>
</a>
<a class="flex items-center gap-3 px-3 py-2.5 rounded-lg hover:bg-primary/10 dark:hover:bg-primary/20" href="/HealthCenter/admin/vaccine_inventory.php">
<span class="material-symbols-outlined">inventory_2</span>
<p class="text-sm font-medium leading-normal">Vaccine Inventory</p>
</a>
<a class="flex items-center gap-3 px-3 py-2.5 rounded-lg hover:bg-primary/10 dark:hover:bg-primary/20" href="/HealthCenter/admin/reports.php">
<span class="material-symbols-outlined">summarize</span>
<p class="text-sm font-medium leading-normal">Reports</p>
</a>
<a class="flex items-center gap-3 px-3 py-2.5 rounded-lg hover:bg-primary/10 dark:hover:bg-primary/20" href="/HealthCenter/admin/system_settings.php">
<span class="material-symbols-outlined">settings</span>
<p class="text-sm font-medium leading-normal">System Settings</p>
</a>
</div>
</div>
<div class="flex flex-col gap-4">
<div class="flex gap-3 items-center">
<div class="bg-center bg-no-repeat aspect-square bg-cover rounded-full size-10" data-alt="Admin User Avatar" style='background-image: url("https://lh3.googleusercontent.com/aida-public/AB6AXuDOA0JtY9jwLMl7Ryzlnw37KuKKDCOzz0ZldiL8HgejOOSQxYRQEXAsPyFFNyRhwHyDGnRM1NUqdFxAQGj-o4GwH4jhwgkiy92YM3jkapeh59te7_ynMRXN8wPO1UzOwIwp1OIONv9rlMXKIkWPS9ACQ0Awm9GUMqVAGB1zQPp-QaX9lIjNh3ziyU1el71c3iONwq2nQJO5WMwLDsiPx7TFHOApOAn6FV_1L6TJjd0aVxs5mn_uLBogTZ-lpNgliuzGgW83rUFEATg");'></div>
<div class="flex flex-col">
<h1 class="text-text-light dark:text-text-dark text-base font-medium leading-normal">Admin User</h1>
<p class="text-text-secondary-light dark:text-text-secondary-dark text-sm font-normal leading-normal">Administrator</p>
</div>
</div>
<div class="flex flex-col">
<a class="flex items-center gap-3 px-3 py-2.5 rounded-lg hover:bg-primary/10 dark:hover:bg-primary/20" href="/HealthCenter/auth/logout.php">
<span class="material-symbols-outlined">logout</span>
<p class="text-sm font-medium leading-normal">Logout</p>
</a>
</div>
</div>
</aside>
<div class="flex flex-1 flex-col">
<header class="flex items-center justify-end whitespace-nowrap border-b border-border-light dark:border-border-dark px-10 py-4 bg-surface dark:bg-surface-dark sticky top-0 z-10">
<div class="flex flex-1 justify-end gap-4">
<button class="relative flex max-w-[480px] cursor-pointer items-center justify-center overflow-hidden rounded-lg h-10 w-10 bg-transparent text-text-secondary-light dark:text-text-secondary-dark hover:bg-primary/10">
<span class="material-symbols-outlined">notifications</span>
<div class="absolute top-1.5 right-1.5 size-2.5 rounded-full bg-danger border-2 border-surface dark:border-surface-dark"></div>
</button>
<div class="bg-center bg-no-repeat aspect-square bg-cover rounded-full size-10" data-alt="Admin User Avatar" style='background-image: url("https://lh3.googleusercontent.com/aida-public/AB6AXuARjArNwKv54rqIrR7CH42FnyccgbltF87KZdCyHPGKKOzScwDN-jjMvPXmD4gCDVvfYS0AIpUNqas5NYm0BA8U00eIzHgBsvb7cu3bgCLNBejNE5SViuJOf9dyPvGxuDchBzt4dBppu1bfA0_q-XeqiYhrrMlYNjUzSywvoCIeWZGrPxXVI9IdoXGEofyWKOpLxVNqu1BqZhAYUgl3Ol6bzJHObRRvWioznewisgIjgWRDHcfstTh-ed4_Kxm0_zOXWnqyrqXcX54");'></div>
</div>
</header>
<main class="flex flex-col flex-1 p-6 lg:p-10 gap-6 lg:gap-10">
<div class="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
<div class="flex min-w-72 flex-col gap-2">
<p class="text-text-light dark:text-text-dark text-3xl font-black leading-tight tracking-tight">User Management</p>
<p class="text-text-secondary-light dark:text-text-secondary-dark text-base font-normal leading-normal">Manage all user accounts in the system.</p>
</div>
<a href="/HealthCenter/admin/user_management.php?action=add" class="flex h-11 items-center justify-center gap-2 whitespace-nowrap rounded-lg bg-primary px-5 text-sm font-semibold text-white shadow-sm hover:bg-primary/90 focus:outline-none focus:ring-2 focus:ring-primary/50 disabled:cursor-not-allowed disabled:opacity-70" role="button">
<span class="material-symbols-outlined text-xl">add</span>
<span>Add New User</span>
</a>
</div>
<div class="flex flex-col gap-6 rounded-lg border border-border-light dark:border-border-dark bg-surface dark:bg-surface-dark p-6">
<div class="flex flex-col md:flex-row gap-4 justify-between">
<label class="flex-1 min-w-40 max-w-sm">
<div class="flex w-full flex-1 items-stretch rounded-lg h-10">
<div class="text-text-secondary-light dark:text-text-secondary-dark flex border-none bg-background-light dark:bg-background-dark items-center justify-center pl-4 rounded-l-lg border-r-0">
<span class="material-symbols-outlined">search</span>
</div>
<input class="form-input flex w-full min-w-0 flex-1 resize-none overflow-hidden rounded-lg text-text-light dark:text-text-dark focus:outline-0 focus:ring-2 focus:ring-primary/50 border-none bg-background-light dark:bg-background-dark h-full placeholder:text-text-secondary-light dark:placeholder:text-text-secondary-dark px-4 rounded-l-none border-l-0 pl-2 text-base font-normal leading-normal" placeholder="Search by name or email..." value=""/>
</div>
</label>
<div class="flex gap-4">
<select class="form-select h-10 rounded-lg border border-border-light dark:border-border-dark bg-surface dark:bg-surface-dark text-text-secondary-light dark:text-text-secondary-dark focus:ring-2 focus:ring-primary/50 focus:border-primary/50">
<option>Filter by Role</option>
<option>Admin</option>
<option>Health Worker</option>
<option>Patient</option>
</select>
<select class="form-select h-10 rounded-lg border border-border-light dark:border-border-dark bg-surface dark:bg-surface-dark text-text-secondary-light dark:text-text-secondary-dark focus:ring-2 focus:ring-primary/50 focus:border-primary/50">
<option>Filter by Status</option>
<option>Active</option>
<option>Inactive</option>
</select>
</div>
</div>
<div class="overflow-x-auto">
<table class="w-full text-left">
<thead>
<tr class="border-b border-border-light dark:divide-border-dark">
<th class="py-3 px-4 text-sm font-semibold text-text-secondary-light dark:text-text-secondary-dark">User</th>
<th class="py-3 px-4 text-sm font-semibold text-text-secondary-light dark:text-text-secondary-dark">Role</th>
<th class="py-3 px-4 text-sm font-semibold text-text-secondary-light dark:text-text-secondary-dark">Status</th>
<th class="py-3 px-4 text-sm font-semibold text-text-secondary-light dark:text-text-secondary-dark">Date Added</th>
<th class="py-3 px-4 text-sm font-semibold text-text-secondary-light dark:text-text-secondary-dark text-right">Actions</th>
</tr>
</thead>
<tbody class="divide-y divide-border-light dark:divide-border-dark">
<tr>
<td class="p-4">
<div class="flex items-center gap-3">
<div class="bg-center bg-no-repeat aspect-square bg-cover rounded-full size-10" style='background-image: url("https://lh3.googleusercontent.com/aida-public/AB6AXuDOA0JtY9jwLMl7Ryzlnw37KuKKDCOzz0ZldiL8HgejOOSQxYRQEXAsPyFFNyRhwHyDGnRM1NUqdFxAQGj-o4GwH4jhwgkiy92YM3jkapeh59te7_ynMRXN8wPO1UzOwIwp1OIONv9rlMXKIkWPS9ACQ0Awm9GUMqVAGB1zQPp-QaX9lIjNh3ziyU1el71c3iONwq2nQJO5WMwLDsiPx7TFHOApOAn6FV_1L6TJjd0aVxs5mn_uLBogTZ-lpNgliuzGgW83rUFEATg");'></div>
<div>
<p class="font-medium text-text-light dark:text-text-dark">Admin User</p>
<p class="text-sm text-text-secondary-light dark:text-text-secondary-dark">admin@hcnvms.com</p>
</div>
</div>
</td>
<td class="p-4 text-sm">Administrator</td>
<td class="p-4"><span class="bg-success/20 text-success px-2 py-0.5 rounded-full text-xs font-semibold">Active</span></td>
<td class="p-4 text-sm">2023-01-15</td>
<td class="p-4 text-right">
<div class="flex justify-end gap-2">
<a href="/HealthCenter/admin/user_management.php?action=edit&id=1" class="flex items-center justify-center size-8 rounded-lg text-text-secondary-light dark:text-text-secondary-dark hover:bg-primary/10 hover:text-primary"><span class="material-symbols-outlined text-xl">edit</span></a>
<a href="/HealthCenter/admin/user_management.php?action=view&id=1" class="flex items-center justify-center size-8 rounded-lg text-text-secondary-light dark:text-text-secondary-dark hover:bg-primary/10 hover:text-primary"><span class="material-symbols-outlined text-xl">visibility</span></a>
<a href="/HealthCenter/admin/user_management.php?action=toggle&id=1" class="flex items-center justify-center size-8 rounded-lg text-danger hover:bg-danger/10"><span class="material-symbols-outlined text-xl">toggle_off</span></a>
</div>
</td>
</tr>
<!-- additional rows omitted for brevity -->
</tbody>
</table>
</div>
<div class="flex flex-col sm:flex-row items-center justify-between pt-4">
<p class="text-sm text-text-secondary-light dark:text-text-secondary-dark mb-4 sm:mb-0">Showing 1 to 5 of 25 users</p>
<div class="flex items-center gap-2">
<button class="flex items-center justify-center size-9 rounded-lg text-text-secondary-light dark:text-text-secondary-dark hover:bg-primary/10 hover:text-primary disabled:opacity-50" disabled=""><span class="material-symbols-outlined text-xl">chevron_left</span></button>
<button class="flex items-center justify-center size-9 rounded-lg text-white bg-primary">1</button>
<button class="flex items-center justify-center size-9 rounded-lg text-text-secondary-light dark:text-text-secondary-dark hover:bg-primary/10 hover:text-primary">2</button>
<button class="flex items-center justify-center size-9 rounded-lg text-text-secondary-light dark:text-text-secondary-dark hover:bg-primary/10 hover:text-primary">3</button>
<span class="text-text-secondary-light dark:text-text-secondary-dark">...</span>
<button class="flex items-center justify-center size-9 rounded-lg text-text-secondary-light dark:text-text-secondary-dark hover:bg-primary/10 hover:text-primary">5</button>
<button class="flex items-center justify-center size-9 rounded-lg text-text-secondary-light dark:text-text-secondary-dark hover:bg-primary/10 hover:text-primary"><span class="material-symbols-outlined text-xl">chevron_right</span></button>
</div>
</div>
</div>
</main>
</div>
</div>

</body></html>
