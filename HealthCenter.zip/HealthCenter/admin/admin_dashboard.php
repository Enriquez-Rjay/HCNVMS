<?php
require_once __DIR__ . '/../config/session.php';
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
  header('Location: /HealthCenter/login.html?error=' . rawurlencode('Please sign in as admin'));
  exit;
}
$displayName = $_SESSION['username'] ?? 'Admin User';

// Database connection for metrics
$mysqli = require __DIR__ . '/../config/db.php';

// Compute dashboard metrics (safe fallbacks if tables absent)
$totalBabies = 0;
$coveragePercent = 0;
$vaccineTypes = 0;
$appointmentsToday = 0;

// total patients (users with role 'patient')
if ($res = $mysqli->query("SELECT COUNT(*) AS c FROM users WHERE role='patient'")) {
  $row = $res->fetch_assoc();
  $totalBabies = (int) ($row['c'] ?? 0);
  $res->free_result();
}

// vaccinated patients (distinct patient_id in vaccination_records)
if ($res = $mysqli->query("SELECT COUNT(DISTINCT patient_id) AS c FROM vaccination_records")) {
  $row = $res->fetch_assoc();
  $vaccinated = (int) ($row['c'] ?? 0);
  $res->free_result();
  if ($totalBabies > 0) {
    $coveragePercent = (int) round($vaccinated / $totalBabies * 100);
  }
}

// vaccine types count
if ($res = $mysqli->query("SELECT COUNT(*) AS c FROM vaccines")) {
  $row = $res->fetch_assoc();
  $vaccineTypes = (int) ($row['c'] ?? 0);
  $res->free_result();
}

// appointments scheduled today
if ($res = $mysqli->query("SELECT COUNT(*) AS c FROM appointments WHERE DATE(scheduled_at) = CURDATE()")) {
  $row = $res->fetch_assoc();
  $appointmentsToday = (int) ($row['c'] ?? 0);
  $res->free_result();
}

// Coverage by vaccine (count vaccinated per vaccine)
$coverageByVaccine = [];
if ($res = $mysqli->query("SELECT v.id, v.name, COALESCE(COUNT(vr.id),0) AS doses FROM vaccines v LEFT JOIN vaccination_records vr ON vr.vaccine_id = v.id GROUP BY v.id, v.name ORDER BY v.name")) {
  while ($row = $res->fetch_assoc()) {
    $name = $row['name'];
    $doses = (int) $row['doses'];
    // percent relative to total patients (if total zero, percent 0)
    $percent = ($totalBabies > 0) ? round(min(100, ($doses / $totalBabies) * 100)) : 0;
    $coverageByVaccine[] = ['name' => $name, 'doses' => $doses, 'percent' => $percent];
  }
  $res->free_result();
}

// Vaccination status breakdown: fully / partially / none
$statusBreakdown = ['fully' => 0, 'partially' => 0, 'none' => 0];
// total vaccine types to define "fully"
$totalVaccineTypes = 0;
if ($r = $mysqli->query("SELECT COUNT(*) AS c FROM vaccines")) {
  $rr = $r->fetch_assoc();
  $totalVaccineTypes = (int) ($rr['c'] ?? 0);
  $r->free_result();
}
if ($totalBabies > 0) {
  // fully: patients having at least one record for every vaccine type
  $fullyQuery = "SELECT COUNT(*) AS c FROM users u WHERE u.role='patient' AND NOT EXISTS (SELECT 1 FROM vaccines v WHERE NOT EXISTS (SELECT 1 FROM vaccination_records vr WHERE vr.patient_id = u.id AND vr.vaccine_id = v.id))";
  if ($r = $mysqli->query($fullyQuery)) {
    $row = $r->fetch_assoc();
    $statusBreakdown['fully'] = (int) ($row['c'] ?? 0);
    $r->free_result();
  }
  // partially: patients with at least one vaccination but not fully
  $partialQuery = "SELECT COUNT(DISTINCT u.id) AS c FROM users u JOIN vaccination_records vr ON vr.patient_id = u.id WHERE u.role='patient'";
  if ($r = $mysqli->query($partialQuery)) {
    $row = $r->fetch_assoc();
    $withAny = (int) ($row['c'] ?? 0);
    $r->free_result();
    $statusBreakdown['partially'] = max(0, $withAny - $statusBreakdown['fully']);
  }
  $statusBreakdown['none'] = max(0, $totalBabies - $statusBreakdown['fully'] - $statusBreakdown['partially']);
}

// Low stock alerts (aggregate quantities per vaccine)
$lowStockAlerts = [];
if ($res = $mysqli->query("SELECT v.id, v.name, COALESCE(SUM(b.quantity_available),0) AS qty FROM vaccines v LEFT JOIN vaccine_batches b ON b.vaccine_id = v.id GROUP BY v.id, v.name HAVING qty <= 50 ORDER BY qty ASC")) {
  while ($row = $res->fetch_assoc()) {
    $qty = (int) $row['qty'];
    $status = ($qty <= 10) ? 'Critical' : 'Low Stock';
    $lowStockAlerts[] = ['name' => $row['name'], 'qty' => $qty, 'status' => $status];
  }
  $res->free_result();
}

// Recent system activity: collect latest rows from different tables
$recentActivities = [];
// newest health workers (join to users for full_name)
if ($res = $mysqli->query("SELECT u.full_name AS text, hw.created_at AS ts FROM health_worker_profiles hw JOIN users u ON u.id = hw.user_id ORDER BY hw.created_at DESC LIMIT 3")) {
  while ($row = $res->fetch_assoc()) {
    $recentActivities[] = ['type' => 'hw', 'text' => 'New health worker ' . ($row['text'] ?? 'Unnamed') . ' added.', 'ts' => $row['ts']];
  }
  $res->free_result();
}
// vaccine transactions (stock updates) - join batch -> vaccine
if ($res = $mysqli->query("SELECT CONCAT('Vaccine stock for ', COALESCE(v.name,'Unknown'), ' ', vt.type) AS text, vt.created_at AS ts FROM vaccine_transactions vt LEFT JOIN vaccine_batches b ON b.id = vt.batch_id LEFT JOIN vaccines v ON v.id = b.vaccine_id ORDER BY vt.created_at DESC LIMIT 3")) {
  while ($row = $res->fetch_assoc()) {
    $recentActivities[] = ['type' => 'stock', 'text' => $row['text'], 'ts' => $row['ts']];
  }
  $res->free_result();
}
// reports
if ($res = $mysqli->query("SELECT r.report_type AS text, r.generated_at AS ts FROM reports r ORDER BY r.generated_at DESC LIMIT 3")) {
  while ($row = $res->fetch_assoc()) {
    $recentActivities[] = ['type' => 'report', 'text' => ($row['text'] ?? 'Report') . ' generated.', 'ts' => $row['ts']];
  }
  $res->free_result();
}
// sort activities by timestamp desc and limit 5
usort($recentActivities, function($a, $b){ return strcmp($b['ts'] ?? '', $a['ts'] ?? ''); });
$recentActivities = array_slice($recentActivities, 0, 5);

function time_ago($ts) {
  if (!$ts) return '';
  $t = strtotime($ts);
  if ($t === false) return $ts;
  $diff = time() - $t;
  if ($diff < 60) return $diff . ' seconds ago';
  if ($diff < 3600) return floor($diff/60) . ' minutes ago';
  if ($diff < 86400) return floor($diff/3600) . ' hours ago';
  return floor($diff/86400) . ' days ago';
}
?>
<!DOCTYPE html>

<html class="light" lang="en"><head>
<meta charset="utf-8"/>
<meta content="width=device-width, initial-scale=1.0" name="viewport"/>
<title>HCNVMS - Admin Dashboard</title>
<script src="https://cdn.tailwindcss.com?plugins=forms,container-queries"></script>
<link href="https://fonts.googleapis.com/css2?family=Public+Sans:wght@400;500;600;700;800;900&amp;display=swap" rel="stylesheet"/>
<link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" rel="stylesheet"/>
<style>
        .material-symbols-outlined {
            font-variation-settings: 'FILL' 0, 'wght' 400, 'GRAD' 0, 'opsz' 24;
        }
    </style>
<script>
      tailwind.config = {
        darkMode: "class",
        theme: {
          extend: {
            colors: {
              "primary": "#4A90E2",
              "background-light": "#F4F7FA",
              "background-dark": "#101922",
              "surface": "#FFFFFF",
              "surface-dark": "#1A242E",
              "text-light": "#333333",
              "text-dark": "#E0E0E0",
              "text-secondary-light": "#617589",
              "text-secondary-dark": "#A0AEC0",
              "border-light": "#E2E8F0",
              "border-dark": "#2D3748",
              "success": "#2ECC71",
              "warning": "#F39C12",
              "danger": "#E74C3C",
            },
            fontFamily: {
              "display": ["Public Sans", "sans-serif"]
            },
            borderRadius: {"DEFAULT": "0.5rem", "lg": "0.75rem", "xl": "1rem", "full": "9999px"},
          },
        },
      }
    </script>
</head>
<body class="font-display bg-background-light dark:bg-background-dark text-text-light dark:text-text-dark">
<div class="relative flex min-h-screen w-full flex-row">
<!-- SideNavBar -->
<aside class="flex h-screen w-64 flex-col justify-between bg-surface dark:bg-surface-dark p-4 border-r border-border-light dark:border-border-dark sticky top-0">
<div class="flex flex-col gap-8">
<div class="flex items-center gap-3 px-3 text-primary">
<span class="material-symbols-outlined text-3xl">vaccines</span>
<h2 class="text-text-light dark:text-text-dark text-xl font-bold leading-tight tracking-[-0.015em]">HCNVMS</h2>
</div>
<div class="flex flex-col gap-2">
<a class="flex items-center gap-3 px-3 py-2.5 rounded-lg bg-primary/20 text-primary" href="/HealthCenter/admin/admin_dashboard.php">
<span class="material-symbols-outlined" style="font-variation-settings: 'FILL' 1;">dashboard</span>
<p class="text-sm font-semibold leading-normal">Dashboard</p>
</a>
<a class="flex items-center gap-3 px-3 py-2.5 rounded-lg hover:bg-primary/10 dark:hover:bg-primary/20" href="/HealthCenter/admin/user_management.php">
<span class="material-symbols-outlined">group</span>
<p class="text-sm font-medium leading-normal">User Management</p>
</a>
<a class="flex items-center gap-3 px-3 py-2.5 rounded-lg hover:bg-primary/10 dark:hover:bg-primary/20" href="/HealthCenter/admin/health_worker_management.php">
<span class="material-symbols-outlined">health_and_safety</span>
<p class="text-sm font-medium leading-normal">Health Worker Mgt.</p>
</a>
<a class="flex items-center gap-3 px-3 py-2.5 rounded-lg hover:bg-primary/10 dark:hover:bg-primary/20" href="/HealthCenter/admin/vaccine_inventory.php">
<span class="material-symbols-outlined">inventory_2</span>
<p class="text-sm font-medium leading-normal">Vaccine Inventory</p>
</a>
<a class="flex items-center gap-3 px-3 py-2.5 rounded-lg hover:bg-primary/10 dark:hover:bg-primary/20" href="/HealthCenter/admin/reports.php">
<span class="material-symbols-outlined">summarize</span>
<p class="text-sm font-medium leading-normal">Reports</p>
</a>
<a class="flex items-center gap-3 px-3 py-2.5 rounded-lg hover:bg-primary/10 dark:hover:bg-primary/20" href="/HealthCenter/admin/system_settings.php">
<span class="material-symbols-outlined">settings</span>
<p class="text-sm font-medium leading-normal">System Settings</p>
</a>
</div>
</div>
<div class="flex flex-col gap-4">
<div class="flex gap-3 items-center">
<div class="bg-center bg-no-repeat aspect-square bg-cover rounded-full size-10" data-alt="Admin User Avatar" style='background-image: url("https://lh3.googleusercontent.com/aida-public/AB6AXuDOA0JtY9jwLMl7Ryzlnw37KuKKDCOzz0ZldiL8HgejOOSQxYRQEXAsPyFFNyRhwHyDGnRM1NUqdFxAQGj-o4GwH4jhwgkiy92YM3jkapeh59te7_ynMRXN8wPO1UzOwIwp1OIONv9rlMXKIkWPS9ACQ0Awm9GUMqVAGB1zQPp-QaX9lIjNh3ziyU1el71c3iONwq2nQJO5WMwLDsiPx7TFHOApOAn6FV_1L6TJjd0aVxs5mn_uLBogTZ-lpNgliuzGgW83rUFEATg");'></div>
<div class="flex flex-col">
<h1 class="text-text-light dark:text-text-dark text-base font-medium leading-normal"><?php echo htmlspecialchars($displayName); ?></h1>
<p class="text-text-secondary-light dark:text-text-secondary-dark text-sm font-normal leading-normal">Administrator</p>
</div>
</div>
<div class="flex flex-col">
<a class="flex items-center gap-3 px-3 py-2.5 rounded-lg hover:bg-primary/10 dark:hover:bg-primary/20" href="/HealthCenter/auth/logout.php">
<span class="material-symbols-outlined">logout</span>
<p class="text-sm font-medium leading-normal">Logout</p>
</a>
</div>
</div>
</aside>
<div class="flex flex-1 flex-col">
<!-- TopNavBar -->
<header class="flex items-center justify-end whitespace-nowrap border-b border-border-light dark:border-border-dark px-10 py-4 bg-surface dark:bg-surface-dark sticky top-0 z-10">
<div class="flex flex-1 justify-between items-center gap-4">
<div class="flex-1"></div>
<div class="flex items-center gap-4">
  <a href="/HealthCenter/auth/logout.php" class="inline-flex items-center gap-2 rounded-md bg-red-500 px-3 py-2 text-white hover:bg-red-600">Logout</a>
  <div class="bg-center bg-no-repeat aspect-square bg-cover rounded-full size-10" data-alt="Admin User Avatar" style='background-image: url("https://lh3.googleusercontent.com/aida-public/AB6AXuARjArNwKv54rqIrR7CH42FnyccgbltF87KZdCyHPGKKOzScwDN-jjMvPXmD4gCDVvfYS0AIpUNqas5NYm0BA8U00eIzHgBsvb7cu3bgCLNBejNE5SViuJOf9dyPvGxuDchBzt4dBppu1bfA0_q-XeqiYhrrMlYNjUzSywvoCIeWZGrPxXVI9IdoXGEofyWKOpLxVNqu1BqZhAYUgl3Ol6bzJHObRRvWioznewisgIjgWRDHcfstTh-ed4_Kxm0_zOXWnqyrqXcX54");'></div>
</div>
</div>
</header>
<!-- Main Content -->
<main class="flex flex-col flex-1 p-6 lg:p-10 gap-6 lg:gap-10">
<!-- PageHeading -->
<div class="flex flex-wrap justify-between gap-3">
<div class="flex min-w-72 flex-col gap-2">
<p class="text-text-light dark:text-text-dark text-3xl font-black leading-tight tracking-tight">Admin Dashboard</p>
<p class="text-text-secondary-light dark:text-text-secondary-dark text-base font-normal leading-normal">Overview of the vaccination monitoring system.</p>
</div>
</div>
<!-- Stats -->
<div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
<div class="flex min-w-[158px] flex-1 flex-col gap-2 rounded-lg p-6 bg-surface dark:bg-surface-dark border border-border-light dark:border-border-dark">
<p class="text-text-secondary-light dark:text-text-secondary-dark text-base font-medium leading-normal">Total Babies Registered</p>
<p class="text-text-light dark:text-text-dark tracking-light text-3xl font-bold leading-tight"><?php echo number_format($totalBabies); ?></p>
<p class="text-success text-sm font-medium leading-normal flex items-center gap-1"> <span class="material-symbols-outlined text-base">trending_up</span> +2.5%</p>
</div>
<div class="flex min-w-[158px] flex-1 flex-col gap-2 rounded-lg p-6 bg-surface dark:bg-surface-dark border border-border-light dark:border-border-dark">
<p class="text-text-secondary-light dark:text-text-secondary-dark text-base font-medium leading-normal">Vaccination Coverage</p>
<p class="text-text-light dark:text-text-dark tracking-light text-3xl font-bold leading-tight"><?php echo htmlspecialchars($coveragePercent); ?>%</p>
<p class="text-success text-sm font-medium leading-normal flex items-center gap-1"> <span class="material-symbols-outlined text-base">trending_up</span> +1.2%</p>
</div>
<div class="flex min-w-[158px] flex-1 flex-col gap-2 rounded-lg p-6 bg-surface dark:bg-surface-dark border border-border-light dark:border-border-dark">
<p class="text-text-secondary-light dark:text-text-secondary-dark text-base font-medium leading-normal">Vaccine Types in Stock</p>
<p class="text-text-light dark:text-text-dark tracking-light text-3xl font-bold leading-tight"><?php echo number_format($vaccineTypes); ?></p>
<p class="text-danger text-sm font-medium leading-normal flex items-center gap-1"> <span class="material-symbols-outlined text-base">trending_down</span> -5%</p>
</div>
<div class="flex min-w-[158px] flex-1 flex-col gap-2 rounded-lg p-6 bg-surface dark:bg-surface-dark border border-border-light dark:border-border-dark">
<p class="text-text-secondary-light dark:text-text-secondary-dark text-base font-medium leading-normal">Appointments Today</p>
<p class="text-text-light dark:text-text-dark tracking-light text-3xl font-bold leading-tight"><?php echo number_format($appointmentsToday); ?></p>
<p class="text-success text-sm font-medium leading-normal flex items-center gap-1"> <span class="material-symbols-outlined text-base">trending_up</span> +10%</p>
</div>
</div>
<!-- Charts -->
<div class="grid grid-cols-1 xl:grid-cols-5 gap-6">
<div class="flex min-w-72 xl:col-span-3 flex-col gap-4 rounded-lg border border-border-light dark:border-border-dark p-6 bg-surface dark:bg-surface-dark">
<p class="text-text-light dark:text-text-dark text-lg font-semibold leading-normal">Vaccination Coverage by Vaccine</p>
<div class="grid min-h-[240px] grid-flow-col gap-6 grid-rows-[1fr_auto] items-end justify-items-center px-3 pt-4">
<?php if (!empty($coverageByVaccine)): ?>
  <?php foreach ($coverageByVaccine as $v): ?>
    <?php $h = max(6, (int) $v['percent']); ?>
    <div class="flex flex-col h-full w-full justify-end items-center gap-2">
      <div class="bg-primary rounded-t w-3/4" style="height: <?php echo htmlspecialchars($h); ?>%;"></div>
      <p class="text-text-secondary-light dark:text-text-secondary-dark text-xs font-medium tracking-wide"><?php echo htmlspecialchars($v['name']); ?></p>
    </div>
  <?php endforeach; ?>
<?php else: ?>
  <div class="text-text-secondary-light px-3">No vaccine data available.</div>
<?php endif; ?>
</div>
</div>
<div class="flex min-w-72 xl:col-span-2 flex-col gap-4 rounded-lg border border-border-light dark:border-border-dark p-6 bg-surface dark:bg-surface-dark">
<p class="text-text-light dark:text-text-dark text-lg font-semibold leading-normal">Vaccination Status Breakdown</p>
<div class="flex-1 flex items-center justify-center min-h-[240px] relative">
<svg class="w-full h-full" viewbox="0 0 36 36">
<path class="stroke-current text-primary/20" d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831" fill="none" stroke-width="3"></path>
<path class="stroke-current text-success" d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831" fill="none" stroke-dasharray="60, 100" stroke-linecap="round" stroke-width="3"></path>
<path class="stroke-current text-warning" d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831" fill="none" stroke-dasharray="30, 100" stroke-dashoffset="-60" stroke-linecap="round" stroke-width="3"></path>
</svg>
<div class="absolute flex flex-col items-center justify-center">
<span class="text-3xl font-bold text-text-light dark:text-text-secondary-dark"><?php echo number_format($totalBabies); ?></span>
<span class="text-sm text-text-secondary-light dark:text-text-secondary-dark">Total Babies</span>
</div>
</div>
<div class="flex justify-center gap-4 text-sm">
<?php
  $tot = max(1, $totalBabies);
  $fullyPct = (int) round(($statusBreakdown['fully'] / $tot) * 100);
  $partialPct = (int) round(($statusBreakdown['partially'] / $tot) * 100);
  $nonePct = max(0, 100 - $fullyPct - $partialPct);
?>
<div class="flex items-center gap-2"><div class="size-3 rounded-full bg-success"></div><span>Fully (<?php echo $fullyPct; ?>%)</span></div>
<div class="flex items-center gap-2"><div class="size-3 rounded-full bg-warning"></div><span>Partially (<?php echo $partialPct; ?>%)</span></div>
<div class="flex items-center gap-2"><div class="size-3 rounded-full bg-primary/20"></div><span>None (<?php echo $nonePct; ?>%)</span></div>
</div>
</div>
</div>
<!-- Alerts & Activities -->
<div class="grid grid-cols-1 xl:grid-cols-2 gap-6">
<!-- Low Stock Alerts -->
<div class="flex flex-col gap-4 rounded-lg border border-border-light dark:border-border-dark p-6 bg-surface dark:bg-surface-dark">
<h3 class="text-text-light dark:text-text-dark text-lg font-semibold leading-normal">Low Stock Alerts</h3>
<div class="overflow-x-auto">
<table class="w-full text-left">
<thead>
<tr class="border-b border-border-light dark:border-border-dark">
<th class="py-2 px-3 text-sm font-semibold text-text-secondary-light dark:text-text-secondary-dark">Vaccine Name</th>
<th class="py-2 px-3 text-sm font-semibold text-text-secondary-light dark:text-text-secondary-dark">Quantity Left</th>
<th class="py-2 px-3 text-sm font-semibold text-text-secondary-light dark:text-text-secondary-dark">Status</th>
</tr>
</thead>
<tbody>
<?php if (!empty($lowStockAlerts)): ?>
  <?php foreach ($lowStockAlerts as $a): ?>
    <tr class="border-b border-border-light dark:border-border-dark">
      <td class="py-3 px-3 text-sm"><?php echo htmlspecialchars($a['name']); ?></td>
      <td class="py-3 px-3 text-sm"><?php echo number_format($a['qty']); ?> vials</td>
      <td class="py-3 px-3 text-sm"><span class="<?php echo $a['status'] === 'Critical' ? 'bg-danger/20 text-danger' : 'bg-warning/20 text-warning'; ?> px-2 py-0.5 rounded-full text-xs font-semibold"><?php echo htmlspecialchars($a['status']); ?></span></td>
    </tr>
  <?php endforeach; ?>
<?php else: ?>
  <tr><td class="py-3 px-3 text-sm" colspan="3">No low stock alerts.</td></tr>
<?php endif; ?>
</tbody>
</table>
</div>
</div>
<!-- Recent System Activity -->
<div class="flex flex-col gap-4 rounded-lg border border-border-light dark:border-border-dark p-6 bg-surface dark:bg-surface-dark">
<h3 class="text-text-light dark:text-text-dark text-lg font-semibold leading-normal">Recent System Activity</h3>
<ul class="space-y-4">
<?php if (!empty($recentActivities)): ?>
  <?php foreach ($recentActivities as $act): ?>
    <li class="flex items-center gap-4">
      <div class="flex items-center justify-center size-9 rounded-full <?php echo $act['type'] === 'hw' ? 'bg-primary/20 text-primary' : ($act['type'] === 'stock' ? 'bg-success/20 text-success' : 'bg-warning/20 text-warning'); ?>">
        <span class="material-symbols-outlined text-xl"><?php echo $act['type'] === 'hw' ? 'person_add' : ($act['type'] === 'stock' ? 'inventory' : 'lab_profile'); ?></span>
      </div>
      <div class="flex-1">
        <p class="text-sm font-medium"><?php echo htmlspecialchars($act['text']); ?></p>
        <p class="text-xs text-text-secondary-light dark:text-text-secondary-dark"><?php echo htmlspecialchars(time_ago($act['ts'] ?? '')); ?></p>
      </div>
    </li>
  <?php endforeach; ?>
<?php else: ?>
  <li class="text-sm text-text-secondary-light">No recent activity.</li>
<?php endif; ?>
</ul>
</div>
</div>
</main>
</div>
</div>
</body></html>
