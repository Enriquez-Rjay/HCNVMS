<?php
require_once __DIR__ . "/../config/session.php";
require_once __DIR__ . "/../config/db.php";

// Health worker dashboard: prepare metrics and upcoming appointments
$dueRecords = [];
$nextAppointment = null;
$progressPercent = 0;
$totalPatientsAssigned = 0;
$appointmentsToday = 0;
$lowStockCount = 0;

if (isset($_SESSION['user_id'])) {
	$hw_id = (int)$_SESSION['user_id'];

	// Next upcoming appointment for this HW
	if ($stmt = $mysqli->prepare("SELECT id, scheduled_at, patient_id, notes, status FROM appointments WHERE health_worker_id = ? AND scheduled_at >= NOW() ORDER BY scheduled_at ASC LIMIT 1")) {
		$stmt->bind_param('i', $hw_id);
		$stmt->execute();
		$res = $stmt->get_result();
		$nextAppointment = $res->fetch_assoc() ?: null;
		$stmt->close();
	}

	// Short list of upcoming appointments
	if ($stmt = $mysqli->prepare("SELECT a.id AS appointment_id, a.patient_id, a.scheduled_at, a.notes, u.full_name AS patient_name FROM appointments a LEFT JOIN users u ON u.id = a.patient_id WHERE a.health_worker_id = ? AND a.status IN ('scheduled','pending') ORDER BY a.scheduled_at ASC LIMIT 50")) {
		$stmt->bind_param('i', $hw_id);
		$stmt->execute();
		$res = $stmt->get_result();
		while ($row = $res->fetch_assoc()) {
			$dueRecords[] = $row;
		}
		$stmt->close();
	}

	// Patients assigned (distinct patient_id in appointments)
	if ($stmt = $mysqli->prepare("SELECT COUNT(DISTINCT patient_id) AS c FROM appointments WHERE health_worker_id = ?")) {
		$stmt->bind_param('i', $hw_id);
		$stmt->execute();
		$r = $stmt->get_result()->fetch_assoc();
		$totalPatientsAssigned = (int)($r['c'] ?? 0);
		$stmt->close();
	}

	// Appointments today
	if ($stmt = $mysqli->prepare("SELECT COUNT(*) AS c FROM appointments WHERE health_worker_id = ? AND DATE(scheduled_at)=CURDATE()")) {
		$stmt->bind_param('i', $hw_id);
		$stmt->execute();
		$r = $stmt->get_result()->fetch_assoc();
		$appointmentsToday = (int)($r['c'] ?? 0);
		$stmt->close();
	}

	// Low stock vaccine batches (threshold 20)
	if ($res = $mysqli->query("SELECT COUNT(*) AS c FROM vaccine_batches WHERE quantity_available < 20")) {
		$r = $res->fetch_assoc();
		$lowStockCount = (int)($r['c'] ?? 0);
		$res->free();
	}

	// Compute patient progress if we have a next appointment
	if (!empty($nextAppointment['patient_id'])) {
		$pid = (int)$nextAppointment['patient_id'];
		$totalVaccines = 0;
		if ($r = $mysqli->query("SELECT COUNT(*) AS c FROM vaccines")) {
			$totalVaccines = (int)(($r->fetch_assoc())['c'] ?? 0);
			$r->free();
		}
		$received = 0;
		if ($stmt = $mysqli->prepare("SELECT COUNT(DISTINCT vaccine_id) AS c FROM vaccination_records WHERE patient_id = ?")) {
			$stmt->bind_param('i', $pid);
			$stmt->execute();
			$rr = $stmt->get_result()->fetch_assoc();
			$received = (int)($rr['c'] ?? 0);
			$stmt->close();
		}
		$progressPercent = $totalVaccines > 0 ? round(($received / $totalVaccines) * 100) : 0;
	}
}

require __DIR__ . "/hw_dashboard.html";
?>
