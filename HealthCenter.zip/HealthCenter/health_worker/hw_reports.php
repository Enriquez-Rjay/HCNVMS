<?php
require_once __DIR__ . '/../config/session.php';
$mysqli = require __DIR__ . '/../config/db.php';

// Simple reports list: recent vaccination records
$reportsList = [];
 $sql = "SELECT vr.id, u.id AS patient_id, u.full_name AS patient_name, u.username AS patient_code,
		  v.name AS vaccine, vr.date_given AS administered_at
	  FROM vaccination_records vr
	  LEFT JOIN users u ON u.id = vr.patient_id
	  LEFT JOIN vaccines v ON v.id = vr.vaccine_id
	  ORDER BY vr.date_given DESC
	  LIMIT 100";
if ($res = $mysqli->query($sql)) {
	while ($row = $res->fetch_assoc()) {
		$reportsList[] = $row;
	}
	$res->free();
}

?>
<!-- Converted from hw_reports.html -->
<?php include __DIR__ . '/../health_worker/hw_reports.html'; ?>
