<?php
require_once __DIR__ . '/../config/session.php';
$mysqli = require __DIR__ . '/../config/db.php';

// Fetch upcoming appointments for this health worker (next 30 days)
$upcomingAppointments = [];
if (isset($_SESSION['user_id'])) {
	$hw_id = (int)$_SESSION['user_id'];
	$sql = "SELECT a.id, a.patient_id, a.scheduled_at, a.notes, a.status,
				   u.full_name AS patient_name, u.username AS patient_code
			FROM appointments a
			LEFT JOIN users u ON u.id = a.patient_id
			WHERE a.health_worker_id = ?
			AND a.scheduled_at >= NOW()
			ORDER BY a.scheduled_at ASC
			LIMIT 20";
	if ($stmt = $mysqli->prepare($sql)) {
		$stmt->bind_param('i', $hw_id);
		$stmt->execute();
		$res = $stmt->get_result();
		while ($row = $res->fetch_assoc()) {
			$upcomingAppointments[] = $row;
		}
		$stmt->close();
	}
}

// Include the static template which will render dynamic aside using $upcomingAppointments
?>
<!-- Converted from hw_schedule.html -->
<?php include __DIR__ . '/../health_worker/hw_schedule.html'; ?>
