<?php
require_once __DIR__ . '/../config/session.php';
$mysqli = require __DIR__ . '/../config/db.php';

// Fetch patients
$patients = [];
$sql = "SELECT u.id, u.username, u.full_name, p.child_name, p.birth_date, p.guardian_name
		FROM users u
		LEFT JOIN patient_profiles p ON p.user_id = u.id
		WHERE u.role = 'patient'
		ORDER BY COALESCE(u.full_name, p.child_name) ASC
		LIMIT 500";
if ($res = $mysqli->query($sql)) {
	while ($row = $res->fetch_assoc()) {
		$patients[] = $row;
	}
	$res->free();
}
?>
<!DOCTYPE html>
<html lang="en"><head>
<meta charset="utf-8"/>
<meta content="width=device-width, initial-scale=1.0" name="viewport"/>
<title>HCNVMS - Patients</title>
<script src="https://cdn.tailwindcss.com?plugins=forms,container-queries"></script>
<link href="https://fonts.googleapis.com" rel="preconnect"/>
<link crossorigin="" href="https://fonts.gstatic.com" rel="preconnect"/>
<link href="https://fonts.googleapis.com/css2?family=Public+Sans:ital,wght@0,100..900;1,100..900&amp;display=swap" rel="stylesheet"/>
<link href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" rel="stylesheet"/>
<style>
		.material-symbols-outlined {
			font-variation-settings: 'FILL' 0,
			'wght' 400,
			'GRAD' 0,
			'opsz' 24
		}
	</style>
<script>
		tailwind.config = {
			darkMode: "class",
			theme: {
				extend: {
					colors: {
						"primary": "#2b8cee",
						"background-light": "#f6f7f8",
						"background-dark": "#101922",
					},
					fontFamily: {
						"display": ["Public Sans", "sans-serif"]
					},
					borderRadius: {
						"DEFAULT": "0.25rem",
						"lg": "0.5rem",
						"xl": "0.75rem",
						"full": "9999px"
					},
				},
			},
		}
	</script>
</head>
<body class="bg-background-light dark:bg-background-dark font-display">
<div class="flex h-screen w-full">
<aside class="flex w-64 flex-col border-r border-slate-200 dark:border-slate-800 bg-white dark:bg-background-dark">
<div class="flex h-16 shrink-0 items-center gap-3 px-6 text-primary">
<span class="material-symbols-outlined text-3xl">vaccines</span>
<h2 class="text-lg font-bold leading-tight tracking-[-0.015em] text-slate-900 dark:text-white">HCNVMS</h2>
</div>
<div class="flex flex-col justify-between h-full p-4">
<div class="flex flex-col gap-2">
  <a class="flex items-center gap-3 rounded-lg px-3 py-2 text-slate-700 hover:bg-slate-100 dark:text-slate-300 dark:hover:bg-slate-800" href="/HealthCenter/health_worker/hw_dashboard.php">
	<span class="material-symbols-outlined">dashboard</span>
	<p class="text-sm font-medium leading-normal">Dashboard</p>
  </a>
  <a class="flex items-center gap-3 rounded-lg bg-primary/10 dark:bg-primary/20 px-3 py-2 text-primary" href="/HealthCenter/health_worker/hw_patient.php">
	<span class="material-symbols-outlined">groups</span>
	<p class="text-sm font-medium leading-normal">Patients</p>
  </a>
  <a class="flex items-center gap-3 rounded-lg px-3 py-2 text-slate-700 hover:bg-slate-100 dark:text-slate-300 dark:hover:bg-slate-800" href="/HealthCenter/health_worker/hw_schedule.php">
	<span class="material-symbols-outlined">calendar_month</span>
	<p class="text-sm font-medium leading-normal">Schedule</p>
  </a>
  <a class="flex items-center gap-3 rounded-lg px-3 py-2 text-slate-700 hover:bg-slate-100 dark:text-slate-300 dark:hover:bg-slate-800" href="/HealthCenter/health_worker/hw_reports.php">
	<span class="material-symbols-outlined">monitoring</span>
	<p class="text-sm font-medium leading-normal">Reports</p>
  </a>
</div>
<div class="flex flex-col gap-4">
<div class="flex flex-col gap-2">
<a class="flex items-center gap-3 rounded-lg px-3 py-2 text-slate-700 hover:bg-slate-100 dark:text-slate-300 dark:hover:bg-slate-800" href="#">
<span class="material-symbols-outlined">settings</span>
<p class="text-sm font-medium leading-normal">Settings</p>
</a>
<a class="flex items-center gap-3 rounded-lg px-3 py-2 text-slate-700 hover:bg-slate-100 dark:text-slate-300 dark:hover:bg-slate-800" href="#">
<span class="material-symbols-outlined">logout</span>
<p class="text-sm font-medium leading-normal">Logout</p>
</a>
</div>
<div class="border-t border-slate-200 dark:border-slate-800 pt-4">
<div class="flex items-center gap-3">
<div class="bg-center bg-no-repeat aspect-square bg-cover rounded-full size-10" data-alt="Profile picture of Dr. Eleanor Vance" style='background-image: url("https://lh3.googleusercontent.com/aida-public/AB6AXuC3YB4FWbnGm_Gc5ceDpNBM-yGGq_x-S8NGoCP9aWaPiHOshgYI_KOqEhf9OKmIv1oxPx3USOxsB5Mzkg32tSJbfJLW6fbAnmxLlcbSY7YRPb6rKXjeKriw0yFpZqDvWD6n_k9K2WJQprJLihXE2HFeQCgdEUH6R9jces7DxNvvRrQMYRu--iWgcpFfOnek0Q4mAIvABHjBKPEB11-YoVieus4ks2vfq6zurkfSEOwGhjx3dDAeBf8ADHMrt7U_Ng-tgb23mzNIAlY");'></div>
<div class="flex flex-col">
<h1 class="text-slate-900 dark:text-white text-sm font-medium leading-normal">Dr. Eleanor Vance</h1>
<p class="text-slate-500 dark:text-slate-400 text-xs font-normal leading-normal">Health Worker</p>
</div>
</div>
</div>
</div>
</div>
</aside>
<main class="flex-1 overflow-y-auto">
<header class="sticky top-0 z-10 flex h-16 items-center justify-end border-b border-solid border-slate-200 dark:border-slate-800 bg-white/80 dark:bg-background-dark/80 backdrop-blur-sm px-6">
<div class="flex items-center gap-4">
<button class="flex h-10 w-10 cursor-pointer items-center justify-center rounded-full bg-transparent text-slate-600 hover:bg-slate-100 dark:text-slate-400 dark:hover:bg-slate-800">
<span class="material-symbols-outlined">notifications</span>
</button>
<div class="bg-center bg-no-repeat aspect-square bg-cover rounded-full size-10" data-alt="Profile picture of Dr. Eleanor Vance" style='background-image: url("https://lh3.googleusercontent.com/aida-public/AB6AXuB2XXrF70A5PzBQOoMcRk4UKBiS8uRKEmypAE_V_YrhiJ4Crj0AC9iY-bXlvDJX4oJLBlxg_ajYkE3KpbddetMvhZBTNgq0FjtUkaLtjezwzoOvZZKoHmKaYlVlFA2bSZijOTHF6D_Y_OCSRKKod_2NkiNdMvgxljbgd3ud1HWiTfm1wKH095VP2ljaZoVvav1jQW4_cHdrd1Kjjmr3-WMCG_kxBy9cF2rTx45yzWWMsEIXA3FHfZvSF2iZLyER_sQCEy1EDylO2MQ");'></div>
</div>
</header>
<div class="p-6 md:p-8">
<div class="flex flex-col gap-4 mb-6 md:flex-row md:items-center md:justify-between">
<div class="flex flex-col gap-1">
<p class="text-2xl font-bold leading-tight tracking-tight text-slate-900 dark:text-white lg:text-3xl">Patient Records</p>
<p class="text-slate-600 dark:text-slate-400 text-base font-normal leading-normal">Manage and view all registered patient information.</p>
</div>
<button class="flex h-10 w-full cursor-pointer items-center justify-center gap-2 overflow-hidden rounded-lg bg-primary px-4 text-sm font-bold text-white shadow-sm transition-all hover:bg-primary/90 md:w-auto">
<span class="material-symbols-outlined text-base">add</span>
<span class="truncate">Register New Baby</span>
</button>
</div>
<?php
// Handle search and status filters via GET
$q = trim($_GET['q'] ?? '');
$status = $_GET['status'] ?? 'all';

$where = "WHERE u.role = 'patient'";
$params = [];
$types = '';
if ($q !== '') {
		$where .= " AND (u.full_name LIKE ? OR u.username LIKE ? OR p.guardian_name LIKE ? )";
		$like = "%" . $q . "%";
		$params[] = &$like; $params[] = &$like; $params[] = &$like;
		$types .= 'sss';
}
if ($status === 'up-to-date') {
		$where .= " AND (SELECT COUNT(DISTINCT vr.vaccine_id) FROM vaccination_records vr WHERE vr.patient_id = u.id) >= (SELECT COUNT(*) FROM vaccines)";
} elseif ($status === 'upcoming') {
		$where .= " AND EXISTS (SELECT 1 FROM appointments a WHERE a.patient_id = u.id AND a.scheduled_at >= NOW())";
} elseif ($status === 'overdue') {
		$where .= " AND (SELECT COUNT(DISTINCT vr.vaccine_id) FROM vaccination_records vr WHERE vr.patient_id = u.id) < (SELECT COUNT(*) FROM vaccines) AND NOT EXISTS (SELECT 1 FROM appointments a WHERE a.patient_id = u.id AND a.scheduled_at >= NOW())";
}

// Rebuild main patients query with applied filters
$patients = [];
$sql = "SELECT u.id, u.username, COALESCE(u.full_name, p.child_name) AS full_name, p.child_name, p.birth_date, p.guardian_name
				FROM users u
				LEFT JOIN patient_profiles p ON p.user_id = u.id
				" . $where . "
				ORDER BY COALESCE(u.full_name, p.child_name) ASC
				LIMIT 500";
if ($stmt = $mysqli->prepare($sql)) {
		if (!empty($params)) {
				// bind params dynamically
				$bind_names[] = $types;
				for ($i = 0; $i < count($params); $i++) {
						$bind_names[] = &$params[$i];
				}
				call_user_func_array(array($stmt, 'bind_param'), $bind_names);
		}
		$stmt->execute();
		$res = $stmt->get_result();
		while ($row = $res->fetch_assoc()) {
				$patients[] = $row;
		}
		$stmt->close();
}
?>

<div class="mb-6 flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
<form method="get" class="flex w-full sm:w-auto items-center gap-3">
	<label class="relative flex min-w-40 max-w-sm flex-1 items-center">
		<span class="material-symbols-outlined absolute left-3 text-slate-500">search</span>
		<input name="q" value="<?php echo htmlspecialchars($q); ?>" class="form-input w-full rounded-lg border-slate-300 bg-white py-2 pl-10 pr-4 text-slate-900 placeholder:text-slate-500 focus:border-primary focus:ring-primary dark:border-slate-700 dark:bg-slate-900 dark:text-white dark:placeholder:text-slate-400" placeholder="Search by name, ID, or parent..." />
	</label>
	<div class="flex items-center gap-3">
		<label class="text-sm font-medium text-slate-700 dark:text-slate-300" for="vaccination-status-filter">Status:</label>
		<select name="status" class="form-select rounded-lg border-slate-300 bg-white text-slate-900 focus:border-primary focus:ring-primary dark:border-slate-700 dark:bg-slate-900 dark:text-white" id="vaccination-status-filter">
			<option value="all" <?php echo $status === 'all' ? 'selected' : ''; ?>>All</option>
			<option value="up-to-date" <?php echo $status === 'up-to-date' ? 'selected' : ''; ?>>Up-to-date</option>
			<option value="upcoming" <?php echo $status === 'upcoming' ? 'selected' : ''; ?>>Upcoming</option>
			<option value="overdue" <?php echo $status === 'overdue' ? 'selected' : ''; ?>>Overdue</option>
		</select>
	</div>
	<div>
		<button type="submit" class="flex h-10 w-full cursor-pointer items-center justify-center gap-2 overflow-hidden rounded-lg bg-primary px-4 text-sm font-bold text-white shadow-sm transition-all hover:bg-primary/90 md:w-auto">Apply</button>
	</div>
	</form>
</div>
<div class="rounded-xl border border-slate-200 bg-white dark:border-slate-800 dark:bg-slate-900">
<div class="overflow-x-auto">
<table class="w-full text-left text-sm">
<thead class="text-xs uppercase text-slate-500 dark:text-slate-400 bg-slate-50 dark:bg-slate-800">
<tr>
<th class="px-6 py-3 font-medium" scope="col">Patient Name / ID</th>
<th class="px-6 py-3 font-medium" scope="col">Date of Birth</th>
<th class="px-6 py-3 font-medium" scope="col">Parent/Guardian</th>
<th class="px-6 py-3 font-medium" scope="col">Vaccination Status</th>
<th class="px-6 py-3 font-medium text-right" scope="col">Actions</th>
</tr>
</thead>
<tbody class="divide-y divide-slate-200 dark:divide-slate-800">
<?php if (!empty($patients)): ?>
	<?php foreach ($patients as $p): ?>
		<tr class="bg-white hover:bg-slate-50 dark:bg-slate-900 dark:hover:bg-slate-800/50">
			<td class="px-6 py-4">
				<div class="font-medium text-slate-900 dark:text-white"><?php echo htmlspecialchars($p['full_name'] ?? $p['child_name'] ?? ''); ?></div>
				<div class="text-xs text-slate-500">ID: <?php echo htmlspecialchars($p['username'] ?? ''); ?></div>
			</td>
			<td class="px-6 py-4 text-slate-600 dark:text-slate-300"><?php echo htmlspecialchars($p['birth_date'] ?? ''); ?></td>
			<td class="px-6 py-4 text-slate-600 dark:text-slate-300"><?php echo htmlspecialchars($p['guardian_name'] ?? ''); ?></td>
			<td class="px-6 py-4">
				<span class="inline-flex items-center rounded-full bg-amber-100 px-2.5 py-0.5 text-xs font-medium text-amber-800 dark:bg-amber-900 dark:text-amber-300">Upcoming</span>
			</td>
			<td class="px-6 py-4 text-right space-x-4"><a class="font-medium text-primary hover:underline" href="/HealthCenter/health_worker/hw_patient.php?patient_id=<?php echo urlencode($p['id']); ?>">View Profile</a></td>
		</tr>
	<?php endforeach; ?>
<?php else: ?>
	<tr class="bg-white"><td class="px-6 py-4" colspan="5">No patients found.</td></tr>
<?php endif; ?>
</tbody>
</table>
</div>
<div class="flex flex-col items-center justify-between gap-4 border-t border-slate-200 p-4 dark:border-slate-800 sm:flex-row">
<span class="text-sm text-slate-600 dark:text-slate-400">Showing <?php echo count($patients); ?> results</span>
<div class="inline-flex rounded-md shadow-sm">
<button class="relative inline-flex items-center rounded-l-md bg-white px-3 py-2 text-sm font-medium text-slate-600 ring-1 ring-inset ring-slate-300 hover:bg-slate-50 dark:bg-slate-800 dark:text-slate-300 dark:ring-slate-700 dark:hover:bg-slate-700">Previous</button>
<button class="relative -ml-px inline-flex items-center rounded-r-md bg-white px-3 py-2 text-sm font-medium text-slate-600 ring-1 ring-inset ring-slate-300 hover:bg-slate-50 dark:bg-slate-800 dark:text-slate-300 dark:ring-slate-700 dark:hover:bg-slate-700">Next</button>
</div>
</div>
</div>
</div>
</main>
</div>

</body></html>
