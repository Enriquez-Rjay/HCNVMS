<?php
require_once __DIR__ . '/../config/session.php';
$mysqli = require __DIR__ . '/../config/db.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: /HealthCenter/health_worker/hw_schedule.php');
    exit;
}

// Only health workers may mark administered
if (empty($_SESSION['user_id']) || ($_SESSION['role'] ?? '') !== 'health_worker') {
    header('Location: /HealthCenter/login.php');
    exit;
}

$appointment_id = isset($_POST['appointment_id']) ? (int)$_POST['appointment_id'] : 0;
if ($appointment_id <= 0) {
    header('Location: /HealthCenter/health_worker/hw_schedule.php');
    exit;
}

// Verify appointment exists and belongs to this health worker
$stmt = $mysqli->prepare('SELECT id, patient_id, health_worker_id FROM appointments WHERE id = ? LIMIT 1');
$stmt->bind_param('i', $appointment_id);
$stmt->execute();
$appt = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$appt || (int)$appt['health_worker_id'] !== (int)$_SESSION['user_id']) {
    header('Location: /HealthCenter/health_worker/hw_schedule.php');
    exit;
}

// Mark appointment completed and optionally insert a vaccination record if vaccine data provided
try {
    $mysqli->begin_transaction();

    $u = $mysqli->prepare('UPDATE appointments SET status = ? WHERE id = ?');
    $status = 'completed';
    $u->bind_param('si', $status, $appointment_id);
    $u->execute();
    $u->close();

    // Optional: create vaccination_records when vaccine_id is provided
    if (!empty($_POST['vaccine_id'])) {
        $vaccine_id = (int)$_POST['vaccine_id'];
        $dose = isset($_POST['dose']) ? (int)$_POST['dose'] : 1;
        $date_given = !empty($_POST['date_given']) ? $_POST['date_given'] : date('Y-m-d');

        $ins = $mysqli->prepare('INSERT INTO vaccination_records (patient_id, vaccine_id, date_given, dose, created_at) VALUES (?, ?, ?, ?, NOW())');
        $patient_id = (int)$appt['patient_id'];
        $ins->bind_param('iisi', $patient_id, $vaccine_id, $date_given, $dose);
        $ins->execute();
        $ins->close();

        // Optionally decrement a vaccine batch if batch_id provided (not implemented here)
    }

    $mysqli->commit();
} catch (Exception $e) {
    $mysqli->rollback();
}

// Redirect back to schedule (or referer)
header('Location: ' . ($_SERVER['HTTP_REFERER'] ?? '/HealthCenter/health_worker/hw_schedule.php'));
exit;

?>
