<?php
require_once __DIR__ . '/../config/session.php';
$mysqli = require __DIR__ . '/../config/db.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: /HealthCenter/health_worker/hw_schedule.php');
    exit;
}

if (empty($_SESSION['user_id']) || ($_SESSION['role'] ?? '') !== 'health_worker') {
    header('Location: /HealthCenter/login.php');
    exit;
}

$appointment_id = isset($_POST['appointment_id']) ? (int)$_POST['appointment_id'] : 0;
if ($appointment_id <= 0) {
    header('Location: /HealthCenter/health_worker/hw_schedule.php');
    exit;
}

// Verify appointment and ownership
$stmt = $mysqli->prepare('SELECT id, patient_id, health_worker_id FROM appointments WHERE id = ? LIMIT 1');
$stmt->bind_param('i', $appointment_id);
$stmt->execute();
$appt = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$appt || (int)$appt['health_worker_id'] !== (int)$_SESSION['user_id']) {
    header('Location: /HealthCenter/health_worker/hw_schedule.php');
    exit;
}

// Record a reminder action by creating a lightweight report entry (acts as a log)
$report_type = 'reminder';
$params = json_encode(['appointment_id' => $appointment_id, 'patient_id' => (int)$appt['patient_id']]);
$generated_by = (int)$_SESSION['user_id'];

$ins = $mysqli->prepare('INSERT INTO reports (report_type, params, generated_by, generated_at) VALUES (?, ?, ?, NOW())');
$ins->bind_param('ssi', $report_type, $params, $generated_by);
$ins->execute();
$ins->close();

// Optionally: trigger SMS/email sending here if integrated. For now we log and redirect.

header('Location: ' . ($_SERVER['HTTP_REFERER'] ?? '/HealthCenter/health_worker/hw_schedule.php'));
exit;

?>
