<?php
// login.php - login form that posts to auth/login.php
session_start();
$error = $_SESSION['error'] ?? '';
unset($_SESSION['error']);
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width,initial-scale=1" />
    <title>Health Center - Login</title>
    <style>
        body{font-family: Arial, sans-serif; padding:40px}
        .login{max-width:360px;margin:0 auto}
        .error{background:#fdd;border:1px solid #f99;padding:8px;margin-bottom:12px}
        label{display:block;margin-top:8px}
        input{width:100%;padding:8px;margin-top:4px}
        button{margin-top:12px;padding:10px 16px}
    </style>
</head>
<body>
<div class="login">
    <h2>Sign In</h2>
    <?php if ($error): ?>
        <div class="error"><?php echo htmlspecialchars($error); ?></div>
    <?php endif; ?>

    <form id="loginForm" action="auth/login.php" method="post" novalidate>
        <label for="username">Username</label>
        <input id="username" name="username" type="text" autocomplete="username" required />

        <label for="password">Password</label>
        <input id="password" name="password" type="password" autocomplete="current-password" required />

        <button type="submit">Login</button>
    </form>

    <p style="margin-top:18px;font-size:.9em">Example accounts: admin/worker/patient — use seeded script to add them.</p>
</div>

<script src="js/auth.js"></script>
</body>
</html>
